const express = require("express")
const app = express()
const PhoneRouter = require("./routes/phoneRouter")
app.use(express.json())
app.use("/Phone",PhoneRouter)
app.listen(3000);
console.log("server is running")
