const express = require("express");
const { newPayment, checkStatus, recurring } = require("../controller/phoneController");
const router = express.Router()
router.post('/payment', newPayment);
router.post('/status', checkStatus);
router.post('/recurring', recurring);
module.exports = router